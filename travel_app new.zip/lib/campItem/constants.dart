import 'package:flutter/material.dart';

Color kPrimaryColor = Color(0xFF7033FF);
Color kPrimaryColorShadow = Color(0xFFF1EBFF);