import 'package:flutter/material.dart';

class billscreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title:Text ("Bill Genertor"),

      ),
    );
  }

}

